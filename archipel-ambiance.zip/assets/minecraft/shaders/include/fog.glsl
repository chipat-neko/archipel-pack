#ifndef MINECRAFT_FOG_GLSL
#define MINECRAFT_FOG_GLSL

layout(std140) uniform Fog {
    vec4 FogColor;
    float FogEnvironmentalStart;
    float FogEnvironmentalEnd;
    float FogRenderDistanceStart;
    float FogRenderDistanceEnd;
    float FogSkyEnd;
    float FogCloudsEnd;
};

float linear_fog_value(float vertexDistance, float fogStart, float fogEnd) {
    if (vertexDistance <= fogStart) {
        return 0.0;
    } else if (vertexDistance >= fogEnd) {
        return 1.0;
    }

    return (vertexDistance - fogStart) / (fogEnd - fogStart);
}

float total_fog_value(float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    return max(linear_fog_value(sphericalVertexDistance, environmentalStart, environmantalEnd), linear_fog_value(cylindricalVertexDistance, renderDistanceStart, renderDistanceEnd));
}

// Archipel (lot 11) : brouillard d'ambiance. Un voile leger monte doucement avec la
// distance, bien avant le brouillard de fin de vue du jeu. Il s'efface quand le
// brouillard du lieu est deja epais (sous l'eau, dans la lave, Nether...).
// Le ciel appelle cette fonction avec renderDistanceStart == renderDistanceEnd : pas de voile.
float archipel_voile(float cylindricalVertexDistance, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd) {
    if (renderDistanceEnd <= renderDistanceStart + 0.5 || renderDistanceEnd <= 0.0) {
        return 0.0;
    }
    float clair = clamp((environmantalEnd - renderDistanceEnd * 0.5) / (renderDistanceEnd * 0.5), 0.0, 1.0);
    float d = cylindricalVertexDistance / renderDistanceEnd;
    return smoothstep(0.30, 1.0, d) * 0.38 * clair;
}

vec4 apply_fog(vec4 inColor, float sphericalVertexDistance, float cylindricalVertexDistance, float environmentalStart, float environmantalEnd, float renderDistanceStart, float renderDistanceEnd, vec4 fogColor) {
    float fogValue = total_fog_value(sphericalVertexDistance, cylindricalVertexDistance, environmentalStart, environmantalEnd, renderDistanceStart, renderDistanceEnd);
    fogValue = max(fogValue, archipel_voile(cylindricalVertexDistance, environmantalEnd, renderDistanceStart, renderDistanceEnd));
    return vec4(mix(inColor.rgb, fogColor.rgb, fogValue * fogColor.a), inColor.a);
}

float fog_spherical_distance(vec3 pos) {
    return length(pos);
}

float fog_cylindrical_distance(vec3 pos) {
    float distXZ = length(pos.xz);
    float distY = abs(pos.y);
    return max(distXZ, distY);
}

#endif
