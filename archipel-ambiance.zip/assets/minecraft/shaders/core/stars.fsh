#version 330
#extension GL_ARB_separate_shader_objects : require

// L'Archipel brise - pack d'ambiance (lot 11) : stars.fsh de Minecraft 26.3, modifie.

#include <minecraft:dynamictransforms.glsl>

layout(location = 0) flat in float ambScintille;

layout(location = 0) out vec4 fragColor;

void main() {
    fragColor = vec4(ColorModulator.rgb, ColorModulator.a * ambScintille);
}
