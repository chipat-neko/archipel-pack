#version 330
#extension GL_ARB_separate_shader_objects : require

// L'Archipel brise - pack d'ambiance (lot 11) : sky.vsh de Minecraft 26.3, modifie.
// Transmet la direction du ciel au fragment pour un degrade plus doux.

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec3 ambDirection;

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);
    ambDirection = Position;
}
