#version 330
#extension GL_ARB_separate_shader_objects : require

// L'Archipel brise - pack d'ambiance (lot 11) : stars.vsh de Minecraft 26.3, modifie.
// Les etoiles scintillent doucement, chacune a son rythme.

#include <minecraft:dynamictransforms.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:globals.glsl>

layout(location = 0) in vec3 Position;

layout(location = 0) flat out float ambScintille;

float ambHasard(float n) {
    return fract(sin(n * 12.9898) * 43758.5453);
}

void main() {
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);
    float etoile = float(gl_VertexIndex / 4);
    float h = ambHasard(etoile);
    float vitesse = floor(300.0 + h * 500.0);
    float onde = sin(6.2831853 * fract(GameTime * vitesse) + h * 6.2831853);
    ambScintille = 0.72 + 0.28 * onde;
}
