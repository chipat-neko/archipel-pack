#version 330
#extension GL_ARB_separate_shader_objects : require

// L'Archipel brise - pack d'ambiance (lot 11) : terrain.fsh de Minecraft 26.3, modifie.
// Ajouts : eau plus belle (reflet du ciel selon l'angle, transparence, reflets qui bougent).
// Le brouillard d'ambiance est dans fog.glsl.

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:texture_sampling.glsl>
#include <minecraft:oit.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif
#include <archipel_ambiance:ambiance.glsl>

uniform sampler2D Sampler0;

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec4 vertexColor;
layout(location = 3) in vec2 texCoord0;
layout(location = 4) in float chunkVisibility;
layout(location = 5) in vec3 ambPos;
layout(location = 6) flat in int ambGenre;
layout(location = 7) in vec2 ambMondeXZ;
layout(location = 8) in float ambCiel;

#ifndef OIT_ALPHA_ONLY
layout(location = 0) out vec4 fragColor;
#endif

vec4 calculateFinalColor(vec4 color) {
    #ifdef OIT_ACCUMULATE
    color = sampleColorForAccumulation(color);
    vec4 fogColor = vec4(FogColor.rgb * color.a, FogColor.a);
    #else
    vec4 fogColor = FogColor;
    #endif
    return apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, fogColor);
}

// Eau : la couleur depend de l'angle de vue (reflet du ciel quand on regarde au loin,
// transparente quand on regarde a ses pieds) ; de petits reflets bougent sur la surface.
// L'opacite ne depend que de la geometrie, pour rester identique dans toutes les passes
// de la transparence amelioree.
float amb_hasard(vec2 p) {
    return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453);
}

// Bruit doux (valeurs au hasard sur une grille, lissees).
float amb_bruit(vec2 p) {
    vec2 i = floor(p);
    vec2 f = fract(p);
    f = f * f * (3.0 - 2.0 * f);
    float a = amb_hasard(i);
    float b = amb_hasard(i + vec2(1.0, 0.0));
    float c = amb_hasard(i + vec2(0.0, 1.0));
    float d = amb_hasard(i + vec2(1.0, 1.0));
    return mix(mix(a, b, f.x), mix(c, d, f.x), f.y);
}

vec4 amb_eau(vec4 color) {
    vec3 n = cross(dFdx(ambPos), dFdy(ambPos));
    float ln = length(n);
    if (ln < 1e-8) return color;
    n /= ln;
    vec3 v = normalize(-ambPos);
    float cosV = abs(dot(n, v));
    float fresnel = pow(1.0 - cosV, 3.0);
    float horizontal = smoothstep(0.75, 0.95, abs(n.y));
    float jour = 0.35 + 0.65 * ambCiel;

    // Eau plus profonde et plus limpide, sans changer sa teinte de biome.
    color.rgb *= vec3(0.80, 0.95, 1.08);

    // Petits reflets qui scintillent et glissent sur la surface (seulement sur l'eau plate, de pres).
    float t = GameTime * 1200.0;
    vec2 p = ambMondeXZ * 3.0;
    float b1 = amb_bruit(p + vec2(t * 0.35, t * 0.21));
    float b2 = amb_bruit(p * 1.7 - vec2(t * 0.27, -t * 0.31));
    float reflet = smoothstep(0.62, 0.95, b1 * b2 * 1.6);
    float proche = 1.0 - smoothstep(20.0, 56.0, length(ambPos));
    color.rgb += vec3(0.22, 0.23, 0.24) * reflet * horizontal * proche * jour;

    // Reflet du ciel (la couleur du brouillard est celle de l'horizon), plus fort au loin.
    vec3 ciel = FogColor.rgb * (0.6 + 0.4 * ambCiel);
    color.rgb = mix(color.rgb, ciel, fresnel * 0.75 * ambCiel * horizontal);

    // Plus transparente a ses pieds, plus opaque en rasant.
    color.a = clamp(mix(color.a * 0.75, color.a + 0.3, fresnel), 0.0, 1.0);
    return color;
}

void main() {
    vec4 color = (UseRgss == 1 ? sampleRGSS(Sampler0, texCoord0, 1.0f / TextureSize) : sampleNearest(Sampler0, texCoord0, 1.0f / TextureSize)) * vertexColor;
    if (ambGenre == 1) {
        color = amb_eau(color);
    }
    #ifndef OIT_ALPHA_ONLY
    color = mix(FogColor * vec4(1, 1, 1, color.a), color, chunkVisibility);
    #endif
    #ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
    #endif

    #ifdef OIT_ALPHA_ONLY
    executeAlphaOnlyPhase(gl_FragCoord.z, color.a);
    #else
    fragColor = calculateFinalColor(color);
    #endif
}
