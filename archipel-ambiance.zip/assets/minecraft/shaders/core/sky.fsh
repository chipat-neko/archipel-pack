#version 330
#extension GL_ARB_separate_shader_objects : require

// L'Archipel brise - pack d'ambiance (lot 11) : sky.fsh de Minecraft 26.3, modifie.
// Ciel plus doux : zenith un peu plus profond, horizon fondu plus haut dans la couleur
// du brouillard (qui prend la couleur du soleil couchant quand on le regarde).

#include <minecraft:fog.glsl>
#include <minecraft:dynamictransforms.glsl>

layout(location = 0) in float sphericalVertexDistance;
layout(location = 1) in float cylindricalVertexDistance;
layout(location = 2) in vec3 ambDirection;

layout(location = 0) out vec4 fragColor;

void main() {
    vec4 ciel = apply_fog(ColorModulator, sphericalVertexDistance, cylindricalVertexDistance, 0.0, FogSkyEnd, FogSkyEnd, FogSkyEnd, FogColor);
    float l = length(ambDirection);
    float hauteur = l > 0.0001 ? clamp(ambDirection.y / l, 0.0, 1.0) : 1.0;
    // Zenith plus profond.
    vec3 zenith = ColorModulator.rgb * vec3(0.76, 0.87, 1.08);
    vec3 c = mix(ciel.rgb, zenith, smoothstep(0.08, 0.8, hauteur) * 0.7);
    // Bande d'horizon plus large et plus douce.
    float horizon = 1.0 - smoothstep(0.0, 0.4, hauteur);
    c = mix(c, FogColor.rgb, horizon * horizon * 0.5 * FogColor.a);
    fragColor = vec4(c, ciel.a);
}
