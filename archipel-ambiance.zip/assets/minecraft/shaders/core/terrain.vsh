#version 330
#extension GL_ARB_separate_shader_objects : require

// L'Archipel brise - pack d'ambiance (lot 11) : terrain.vsh de Minecraft 26.3, modifie.
// Ajouts : feuilles, herbe, fleurs et cultures qui ondulent ; petites vagues sur l'eau.
// Le jeu ne dit pas au shader de quel bloc vient un sommet : on le devine avec
// la couche (decoupee / translucide), la teinte du biome, la forme du modele et
// quelques pixels de la texture.

#include <minecraft:fog.glsl>
#include <minecraft:globals.glsl>
#include <minecraft:projection.glsl>
#include <minecraft:sample_lightmap.glsl>
#include <minecraft:terrainglobals.glsl>
#ifndef MULTIDRAW_TERRAIN
    #include <minecraft:chunksection.glsl>
#endif
#include <archipel_ambiance:ambiance.glsl>

layout(location = 0) in vec3 Position;
layout(location = 1) in vec4 Color;
layout(location = 2) in vec2 UV0;
layout(location = 3) in ivec2 UV2;
#ifdef MULTIDRAW_TERRAIN
layout(location = 4) in ivec3 ChunkPosition;
layout(location = 5) in float ChunkVisibility;
#endif

uniform sampler2D Sampler0;
#ifndef OIT_ALPHA_ONLY
uniform sampler2D Sampler2;
#endif

layout(location = 0) out float sphericalVertexDistance;
layout(location = 1) out float cylindricalVertexDistance;
layout(location = 2) out vec4 vertexColor;
layout(location = 3) out vec2 texCoord0;
layout(location = 4) out float chunkVisibility;
layout(location = 5) out vec3 ambPos;
layout(location = 6) flat out int ambGenre;
layout(location = 7) out vec2 ambMondeXZ;
layout(location = 8) out float ambCiel;

const int GENRE_RIEN = 0;
const int GENRE_EAU = 1;
const int GENRE_FEUILLAGE = 2;
const int GENRE_PLANTE = 3;

// Au-dela, on ne calcule plus rien : le mouvement ne se verrait pas.
const float DISTANCE_ONDULATION = 48.0;

bool amb_teinte(vec3 c) {
    float mx = max(c.r, max(c.g, c.b));
    float mn = min(c.r, min(c.g, c.b));
    return mx - mn > 0.015;
}

// Poudre de redstone : teintee en rouge, ne doit jamais bouger.
bool amb_rouge(vec3 c) {
    return c.g < c.r * 0.35 && c.b < c.r * 0.15;
}

bool amb_entier(vec3 p) {
    vec3 e = abs(p - round(p));
    return max(e.x, max(e.y, e.z)) < 0.002;
}

vec4 amb_pixel(ivec2 t, ivec2 taille) {
    return texelFetch(Sampler0, clamp(t, ivec2(0), taille - 1), 0);
}

// Le sommet est au coin d'une texture (sprite) de l'atlas, mais le jeu ne dit pas
// quel coin (l'ordre des sommets change d'un troncon a l'autre). On le retrouve dans
// l'atlas : autour de chaque sprite, le jeu recopie ses bords sur 16 pixels (mipmaps
// au niveau 4, le reglage par defaut). Dans ces marges, les pixels ne changent pas en
// s'eloignant du sprite ; dans le sprite, si. On regarde donc les 4 sprites possibles.
bool amb_diff(vec4 a, vec4 b) {
    return any(greaterThan(abs(a - b), vec4(0.02)));
}

ivec2 amb_variation(ivec2 o, ivec2 taille) {
    vec4 g[9];
    for (int j = 0; j < 3; j++) {
        for (int i = 0; i < 3; i++) {
            g[j * 3 + i] = amb_pixel(o + ivec2(3 + 5 * i, 3 + 5 * j), taille);
        }
    }
    int dh = 0;
    int dv = 0;
    for (int j = 0; j < 3; j++) {
        for (int i = 0; i < 2; i++) {
            if (amb_diff(g[j * 3 + i], g[j * 3 + i + 1])) dh++;
        }
    }
    for (int j = 0; j < 2; j++) {
        for (int i = 0; i < 3; i++) {
            if (amb_diff(g[j * 3 + i], g[j * 3 + i + 3])) dv++;
        }
    }
    return ivec2(dh, dv);
}

// Devine si la face appartient a un feuillage (cube de feuilles) ou a une plante.
int amb_classer(ivec2 o, ivec2 taille, bool teinte, bool entier, float yFrac, bool coinHaut) {
    int n = 0;
    int nBas = 0;
    int trous = 0;
    int verts = 0;
    float lum = 0.0;
    for (int j = 0; j < 8; j++) {
        for (int i = 0; i < 8; i++) {
            vec4 c = amb_pixel(o + ivec2(1 + 2 * i, 1 + 2 * j), taille);
            if (c.a >= 0.5) {
                n++;
                if (j >= 4) nBas++;
                float mx = max(c.r, max(c.g, c.b));
                float mn = min(c.r, min(c.g, c.b));
                if (c.g > c.r * 1.04 && c.g > c.b * 1.4 && mx - mn > 0.4 * mx) verts++;
                lum += mx;
            } else if (i >= 2 && i <= 5 && j >= 2 && j <= 5) {
                trous++;
            }
        }
    }
    if (n == 0) return GENRE_RIEN;
    int haut = 0;
    for (int i = 0; i < 8; i++) {
        if (amb_pixel(o + ivec2(2 * i, 0), taille).a >= 0.5) haut++;
    }
    float couverture = float(n) / 64.0;
    float couvBas = float(nBas) / 32.0;
    float lumMoy = lum / float(n);
    bool vegetal = teinte || float(verts) >= 0.25 * float(n);

    if (entier) {
        // Cube entier : feuilles (trouees partout, bord du haut pas plein).
        bool forme = couverture >= 0.40 && couverture <= 0.97 && haut >= 2 && haut <= 7
            && trous >= 1 && couvBas >= 0.2;
        if (forme && lumMoy >= 0.30 && (vegetal || lumMoy >= 0.45)) return GENRE_FEUILLAGE;
        return GENRE_RIEN;
    }
    // Plante : seuls les sommets du haut bougent, et seulement si le haut de la
    // texture est libre (sinon c'est le bas d'une grande plante : il reste fixe
    // pour ne pas se decoller de sa moitie du haut).
    if (vegetal && haut < 3 && couverture <= 0.9 && coinHaut) {
        bool hauteurPlante = yFrac < 0.002 || yFrac > 0.79;
        if (hauteurPlante) return GENRE_PLANTE;
    }
    return GENRE_RIEN;
}

void main() {
    vec3 pos = Position + (ChunkPosition - CameraBlockPos) + CameraOffset;
    // Position dans le monde ramenee sur 1024 blocs (toutes les ondes divisent 1024).
    ivec3 section = ChunkPosition & ivec3(1023);
    vec3 monde = vec3(float(section.x), float(ChunkPosition.y), float(section.z)) + Position;

    int genre = GENRE_RIEN;
    float dist = length(pos);
    bool teinte = amb_teinte(Color.rgb) && !amb_rouge(Color.rgb);

    #ifdef ALPHA_CUTOUT
    if (ALPHA_CUTOUT < 0.3) {
        // Couche translucide : l'eau est la seule chose teintee par le biome.
        if (teinte) {
            genre = GENRE_EAU;
            float yFrac = fract(Position.y);
            if (yFrac > 0.02 && yFrac < 0.98 && dist < 96.0) {
                pos.y += 0.04 * amb_vagues(monde.xz, GameTime);
            }
        }
    } else if (dist < DISTANCE_ONDULATION) {
        // Couche decoupee : feuilles, herbe, fleurs, cultures... et beaucoup d'autres choses.
        bool entier = amb_entier(Position);
        float yFrac = fract(Position.y);
        // Hauts de plantes : a hauteur entiere, un peu plus bas pour l'herbe et les fougeres
        // (le jeu les enfonce au hasard jusqu'a 0,2 bloc) ou a 15/16 pour les cultures.
        bool hauteurPossible = entier || yFrac < 0.002 || yFrac > 0.79;
        if (hauteurPossible) {
            ivec2 c = ivec2(round(UV0 * vec2(TextureSize)));
            ivec2 vPP = amb_variation(c, TextureSize);
            ivec2 vMP = amb_variation(c - ivec2(16, 0), TextureSize);
            ivec2 vPM = amb_variation(c - ivec2(0, 16), TextureSize);
            ivec2 vMM = amb_variation(c - ivec2(16, 16), TextureSize);
            bool plusU = vPP.x + vPM.x > 0;
            bool moinsU = vMP.x + vMM.x > 0;
            bool plusV = vPP.y + vMP.y > 0;
            bool moinsV = vPM.y + vMM.y > 0;
            int su = plusU == moinsU ? 0 : (plusU ? 1 : -1);
            int sv = plusV == moinsV ? 0 : (plusV ? 1 : -1);
            if (su != 0 && sv != 0) {
                // Origine du sprite (16 x 16) ; sv > 0 : le sommet est en haut de la texture.
                ivec2 o = ivec2(su > 0 ? c.x : c.x - 16, sv > 0 ? c.y : c.y - 16);
                genre = amb_classer(o, TextureSize, teinte, entier, yFrac, sv > 0);
            }
        }
        // Le mouvement s'efface doucement avant la limite.
        float force = 1.0 - smoothstep(DISTANCE_ONDULATION * 0.75, DISTANCE_ONDULATION, dist);
        if (genre == GENRE_FEUILLAGE) {
            float a = amb_vent(monde, GameTime);
            float b = amb_vent2(monde, GameTime);
            pos += vec3(a * 0.045, (a - b) * 0.012, b * 0.045) * force;
        } else if (genre == GENRE_PLANTE) {
            float a = amb_vent(monde, GameTime);
            float b = amb_vent2(monde, GameTime);
            pos += vec3(a * 0.10, -abs(a) * 0.015, b * 0.07) * force;
        }
    }
    #endif

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    #ifndef OIT_ALPHA_ONLY
    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    #else
    vertexColor = Color;
    #endif
    #ifdef AMB_DEBUG
    if (genre == GENRE_FEUILLAGE) vertexColor.rgb = vec3(1.0, 0.15, 0.1);
    if (genre == GENRE_PLANTE) vertexColor.rgb = vec3(0.1, 0.3, 1.0);
    if (genre == GENRE_EAU) vertexColor.rgb = vec3(0.0, 1.0, 1.0);
    #endif
    texCoord0 = UV0;

    ambPos = pos;
    ambGenre = genre;
    ambMondeXZ = monde.xz;
    ambCiel = clamp(float(UV2.y) / 240.0, 0.0, 1.0);

    const float chunkFullyVisibleRange = 16.0;
    chunkVisibility = mix(1.0, ChunkVisibility, clamp((dist - chunkFullyVisibleRange) / chunkFullyVisibleRange, 0.0, 1.0));
}
