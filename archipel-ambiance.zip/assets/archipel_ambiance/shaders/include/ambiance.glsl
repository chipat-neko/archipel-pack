// L'Archipel brise - pack d'ambiance (lot 11, ArchipelAmbiance)
// Fonctions communes aux core shaders du pack d'ambiance.
// Minecraft 26.3 (format de pack 97). A refaire a chaque nouvelle version du jeu.
#ifndef ARCHIPEL_AMBIANCE_GLSL
#define ARCHIPEL_AMBIANCE_GLSL

// Mode essai : decommenter pour colorer ce que le shader reconnait
// (rouge = feuillage, bleu = haut des plantes, cyan = eau).
//#define AMB_DEBUG

const float AMB_TAU = 6.2831853;

// Temps en tours : GameTime fait un tour en 24000 ticks (20 min).
// On multiplie par un entier pour que l'animation ne saute jamais au bout des 20 min.
float amb_phase(float gameTime, float toursPar20min) {
    return AMB_TAU * fract(gameTime * toursPar20min);
}

// Vent : valeur douce entre -1 et 1, continue dans l'espace (meme valeur pour deux
// sommets au meme endroit, donc pas de trou entre deux blocs voisins).
// p = position dans le monde ramenee sur 1024 blocs ; toutes les longueurs d'onde
// divisent 1024, il n'y a donc pas de couture.
float amb_vent(vec3 p, float gameTime) {
    float a = sin(amb_phase(gameTime, 560.0) + p.x * 0.3926991 + p.z * 0.1963495 + p.y * 0.1963495);
    float b = sin(amb_phase(gameTime, 830.0) + (p.x + p.z) * 0.7853982);
    float rafale = 0.65 + 0.35 * sin(amb_phase(gameTime, 37.0) + p.x * 0.0490874 + p.z * 0.0245437);
    return (a * 0.7 + b * 0.3) * rafale;
}

float amb_vent2(vec3 p, float gameTime) {
    float a = sin(amb_phase(gameTime, 610.0) + p.z * 0.3926991 - p.x * 0.1963495);
    float b = sin(amb_phase(gameTime, 970.0) + (p.x - p.z) * 0.7853982);
    float rafale = 0.65 + 0.35 * sin(amb_phase(gameTime, 37.0) + p.x * 0.0490874 + p.z * 0.0245437);
    return (a * 0.7 + b * 0.3) * rafale;
}

// Petites vagues de l'eau, entre -1 et 1.
float amb_vagues(vec2 p, float gameTime) {
    float a = sin(amb_phase(gameTime, 420.0) + p.x * 0.7853982 + p.y * 0.3926991);
    float b = sin(amb_phase(gameTime, 650.0) - p.x * 0.3926991 + p.y * 0.7853982);
    float c = sin(amb_phase(gameTime, 1130.0) + (p.x + p.y) * 1.5707963);
    return a * 0.45 + b * 0.4 + c * 0.15;
}

float amb_luminance(vec3 c) {
    return dot(c, vec3(0.2126, 0.7152, 0.0722));
}

#endif
